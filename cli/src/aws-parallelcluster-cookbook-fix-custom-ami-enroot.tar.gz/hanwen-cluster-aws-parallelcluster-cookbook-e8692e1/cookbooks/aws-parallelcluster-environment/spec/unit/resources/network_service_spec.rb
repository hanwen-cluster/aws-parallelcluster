require 'spec_helper'

class ConvergeNetworkService
  def self.restart(chef_run)
    chef_run.converge_dsl('aws-parallelcluster-environment') do
      network_service 'restart' do
        action :restart
      end
    end
  end

  def self.reload(chef_run)
    chef_run.converge_dsl('aws-parallelcluster-environment') do
      network_service 'reload' do
        action :reload
      end
    end
  end
end

describe 'network_service:restart' do
  for_all_oses do |platform, version|
    context "on #{platform}#{version}" do
      cached(:chef_run) do
        runner = runner(platform: platform, version: version, step_into: ['network_service'])
        ConvergeNetworkService.restart(runner)
      end
      cached(:node) { chef_run.node }
      cached(:network_service_name) do
        if platform == 'amazon' && version == '2' || platform == 'centos'
          'network'
        elsif platform == 'amazon' && version == '2023'
          'systemd-networkd'
        elsif platform == 'ubuntu'
          'systemd-resolved'
        elsif %(redhat rocky).include?(platform)
          'NetworkManager'
        else
          raise "Cannot determine network_service_name: unrecognized platform #{platform}"
        end
      end

      it "restarts network service" do
        is_expected.to restart_network_service('restart')
        network_services_to_restart = if platform == 'amazon' && version == '2023'
                                        [network_service_name, 'systemd-resolved']
                                      else
                                        [network_service_name]
                                      end

        is_expected.to write_log("Restarting '#{network_services_to_restart.join(' ')}' service, platform #{platform} '#{node['platform_version']}'")

        is_expected.to restart_service(network_service_name)
          .with(ignore_failure: true)
      end
    end
  end
end

describe 'network_service:reload' do
  for_all_oses do |platform, version|
    context "on #{platform}#{version}" do
      cached(:chef_run) do
        runner = runner(platform: platform, version: version, step_into: ['network_service'])
        ConvergeNetworkService.reload(runner)
      end
      cached(:network_service_name) do
        if platform == 'amazon' && version == '2' || platform == 'centos'
          'network'
        elsif platform == 'amazon' && version == '2023'
          'systemd-networkd'
        elsif platform == 'ubuntu'
          'systemd-resolved'
        elsif %(redhat rocky).include?(platform)
          'NetworkManager'
        else
          raise "Cannot determine network_service_name: unrecognized platform #{platform}"
        end
      end

      it 'reloads network_service' do
        is_expected.to reload_network_service('reload')
      end

      if platform == 'ubuntu'
        it "applies network configuration" do
          is_expected.to run_execute("apply network configuration")
            .with(command: "netplan apply")
            .with(timeout: 60)
        end

        it "doesn't restart network service" do
          is_expected.not_to restart_service(network_service_name)
        end
      else
        it "restarts network service" do
          is_expected.to restart_service(network_service_name)
        end
      end
    end
  end
end
