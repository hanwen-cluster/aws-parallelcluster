# frozen_string_literal: true

# Copyright:: 2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# A copy of the License is located at
#
# http://aws.amazon.com/apache2.0/
#
# or in the "LICENSE.txt" file accompanying this file.
# This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied.
# See the License for the specific language governing permissions and limitations under the License.

action :configure do
  execute 'Configure Directory Service' do
    user 'root'
    environment 'DEBIAN_FRONTEND' => 'noninteractive'
    # Enable PAM mkhomedir module
    command "pam-auth-update --enable mkhomedir"
    default_env true
    sensitive true
  end
end

action_class do
  def required_packages
    %w(sssd sssd-tools sssd-ldap)
  end
end
